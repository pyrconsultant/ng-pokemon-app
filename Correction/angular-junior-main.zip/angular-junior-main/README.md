# Apprendre Angular: Développez facilement votre première application avec TypeScript !
*Ce dépôt Github contient le code de la correction de la formation "Apprendre Angular".*
<img width="400" height="640" src="./learn-angular-cover.jpeg"/>
